#!/bin/bash
java -jar IPSX-Desktop-Client.jar


